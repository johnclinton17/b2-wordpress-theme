<?php
/**
* Template Name: Service
 */

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<!-- banner -->
<section class="innerbanner" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center 0 /cover ;"> 
  <div class="container">
      <div class="row"> 
          <div class="wrap-banner-content">
            <div class="wrap-text">
              <?php the_content();?>
            </div>
          </div>
      </div>
    </div>
</section>      
<!-- banner -->
<!-- reinvent section -->
<?php if( get_field('reinvent_content') ): ?>
<section class="reinvent-section">
  <div class="container">
    <div class="row">
      <div class="about-content wow fadeInUp">
        <?php the_field('reinvent_content');?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>
<!-- reinvent section -->
<!-- services row -->
<section class="service-section">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-centered">
        <?php
          if( have_rows('service_row') ):
          while ( have_rows('service_row') ) : the_row(); ?>
          <div class="service-rows eqWrap wow fadeInUp">
            <div class="image-service equalHW eq">
              <img src="<?php the_sub_field('image');?>" alt="services-icons">
            </div>
            <div class="content-service equalHW eq">
              <?php the_sub_field('content');?>
            </div>
          </div>
        <?php endwhile;endif?> 
      </div>
    </div>
  </div>
</section>
<!-- let us know section -->
<section class="let-us-know wow fadeIn">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-centered">
        <div class="black-box">
          <h2>There's a Better Way to Manage Your Business</h2>
          <p>We’ll help you make a splash in the real world or help digital-only brands transition to a presence to brick and mortar as well.</p>
          <a href="<?php echo esc_url( home_url( '/' )); ?>contact">Let’s talk</a>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- let us know section -->
<?php endwhile; // end of the loop. ?>  
<?php
get_footer();
