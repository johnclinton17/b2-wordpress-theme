<?php
/**
* Template Name: front-page
 */

get_header(); ?>

<!--page contentrs starts here-->
  <main class="page_template">
      <!-- banner section -->
      <section class="banner_section">
        <div class="flexslider">
              <ul class="slides">
                  <?php
                  $args = array( 'posts_per_page' => 5,'post_type' =>'home_banner','post_status'=> 'publish','orderby' => 'date','order' => 'ASC');
                  $bannerposts = get_posts( $args );
                  foreach ( $bannerposts as $bpost ) : setup_postdata( $bpost );
                  $bannerimg = wp_get_attachment_url( get_post_thumbnail_id($bpost->ID) );
                  $custom=get_post_custom($bpost->ID);?>
                      <li>
                        <div class="bannerfill" style="background:url('<?php echo $bannerimg;?>') no-repeat scroll center center / cover ;">
                          <div class="container parent">
                            <div class="row">
                                <div class="content" data-center="bottom:0px;" data-top-bottom="bottom:250px;" data-anchor-target=".bannerfill">
                                    <?php the_content(); ?>   
                                    <div class="arrow-banner"><a href="javascript:void(0)" id="scrolldown"></a></div>
                                </div>
                              </div>
                          </div>
                        </div>
                      </li>     
              
                  <?php endforeach; 
                  wp_reset_postdata();?>
              </ul>
          </div>
        </section>
        <!-- banner section -->
        <!-- about section -->
        <section class="about-section">
            <div class="container">
              <div class="row">
                <div class="col-md-6 about-image pull-right">
                  <img src="<?php the_field('about_image');?>" alt="infographic about">
                </div>
                <div class="col-md-6 about-content">
                  <?php the_field('about_content');?>
                </div>
              </div>


            </div>
        </section>
        <!-- about section -->
        <!-- retailer section -->
        <section class="retail-section">
          <div class="dots-info"></div>
          <div class="container">
            <div class="row">
              <div class="reatil-head">
                <?php the_field('retail_head');?>
              </div>
              <div class="retail-content">
               <?php the_field('retail_content');?>
              </div>
              <div class="retail-image" id="retail-image-container">
                <!-- <img src="<?php the_field('retail_image');?>" alt="retail image"> -->
                <!-- <img src="<?php echo get_template_directory_uri() ?>/images/Index_banner.svg" alt="retail image"> -->
              </div>
            </div>
          </div>
        </section>
        <!-- retailer section -->
        <!-- contact form -->
        <section class="form-section">
          <div class="dots-info-form"></div>
          <div class="container">
            <div class="row">
              <div class="form-head">
                <h1>Transform Your Retail Presence</h1>
              </div>
              <div class="form-row">
                <div class="col-lg-8 col-md-8 col-sm-10 col-xs-12 col-centered">
                  <?php echo do_shortcode('[contact-form-7 id="46" title="homepage retail form"]'); ?>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- contact form -->

<script src="<?php echo get_template_directory_uri() ?>/js/lottie.min.js" type="text/javascript"></script>
<script type="text/javascript">
// config files for animation
var animation = bodymovin.loadAnimation({
 container: document.getElementById('retail-image-container'),
 animType: 'svg',
 loop: false,
 autoplay:false,
 path: '<?php echo get_template_directory_uri() ?>/images/data.json'
});

animation.addEventListener('complete',DoAnimationLoop);

function DoAnimationLoop() {
    setTimeout(function(){lottie.stop();lottie.play(); }, 2500);
}

// on div enter and leave $animate code 
(function($) {

  $.fn.visible = function(partial) {
    
      var $t            = $(this),
          $w            = $(window),
          viewTop       = $w.scrollTop(),
          viewBottom    = viewTop + $w.height(),
          _top          = $t.offset().top,
          _bottom       = _top + $t.height(),
          compareTop    = partial === true ? _bottom : _top,
          compareBottom = partial === true ? _top : _bottom;
    
    return ((compareBottom <= viewBottom) && (compareTop >= viewTop));

  };
    
})(jQuery);

jQuery(window).scroll(function(event) {
  
  jQuery(".retail-section").each(function(i, el) {
    var el = jQuery(el);
    if (el.visible(true)) {
      // el.addClass("fadeIn"); 
      lottie.play();
    } else {
      // el.removeClass("fadeIn");
      lottie.stop();
    }
  });
  
});



</script>

<?php
get_footer();?>
