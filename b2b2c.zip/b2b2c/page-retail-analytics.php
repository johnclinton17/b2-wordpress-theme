<?php
/**
* Template Name:  Retail Analytics
 */

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

<!-- banner -->
<section class="innerbanner" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center 0 /cover ;"> 
  <div class="container">
      <div class="row"> 
          <div class="wrap-banner-content">
            <div class="wrap-text wow fadeInUp">
              <?php the_content();?>
            </div>
          </div>
      </div>
    </div>
</section>      
<!-- banner -->
<!-- reinvent section -->
<?php if( get_field('reinvent_content') ): ?>
<section class="reinvent-section">
  <div class="container">
    <div class="row">
      <div class="about-content wow fadeInUp">
        <?php the_field('reinvent_content');?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>
<!-- reinvent section -->
 <!-- digital white row -->
 <?php if( get_field('white-bg-title') ): ?>
 <section class="white-content-row">
   <div class="container">
    <div class="row">
      <div class="title-head wow fadeInUp"><?php the_field('white-bg-title');?></div>
      <div class="eqWrap wow fadeInUp">
          <div class="content-service equalHW eq">
            <?php the_field('white_left_content');?>
          </div>
          <div class="content-service equalHW eq">
            <?php the_field('white_right_content');?>
          </div>
      </div>
    </div>
   </div>
 </section>

 <?php endif; ?>
 <!-- digital white row -->
 <?php if( get_field('info_seperator') ): ?>
 
<section class="image-seperator ">
  <div class="container">
    <div class="row">
      <div class="image-info wow fadeInUp"><img src="<?php the_field('info_seperator');?>" alt="strategy-infographic"></div>
    </div>
  </div>
</section>
 <?php endif; ?>
<!-- services row -->
<section class="retail-service-section">
  <div class="container">
    <div class="row">
      <?php if( get_field('title') ): ?><div class="title-head wow fadeInUp"><?php the_field('title');?></div><?php endif; ?>
      <?php if( get_field('paragraph_content') ): ?><div class="title-content wow fadeInUp"><?php the_field('paragraph_content');?></div><?php endif; ?>
        <?php
        if( have_rows('service_row') ): $i=1; ?>
      <div class="retail-rows eqWrap wow fadeInUp">
        <?php while ( have_rows('service_row') ) : the_row(); ?>
          <div class="equalHW eq">
            <?php if( get_sub_field('image') ): ?>
              <div class="content-service ">
                <div class="content-service-image"><img src="<?php the_sub_field('image');?>" alt="icons service"></div>
                <div class="content-service-content"><?php the_sub_field('content');?></div>
              </div>
            <?php endif; ?>
          </div>
        <?php if ($i%2==0) { echo "</div><div class='retail-rows eqWrap wow fadeInUp'>"; } $i++; endwhile;?> 
        </div>
        <?php  endif; ?>
    </div>
  </div>
</section>

<!-- let us know section -->
<section class="let-us-know wow fadeIn">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-centered">
        <div class="black-box">
          <h2>There's a Better Way to Manage Your Business</h2>
          <p>We’ll help you make a splash in the real world or help digital-only brands transition to a presence to brick and mortar as well.</p>
          <a href="<?php echo esc_url( home_url( '/' )); ?>contact">Let’s talk</a>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- let us know section -->
<?php endwhile; // end of the loop. ?>  
<?php
get_footer();
