<?php
/**
* Template Name: contact
 */

get_header(); ?>

<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
$page_title = $post->post_name;
?>

  <!-- banner -->
<section class="innerbanner" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center 0 /cover ;"> 
  <div class="container">
      <div class="row"> 
          <div class="wrap-banner-content">
            <div class="wrap-text">
              <h2><?php the_content();?></h2>
            </div>
          </div>
      </div>
    </div>
</section>      
<!-- banner -->

<section class="contact-section">
  <div class="container">
      <div class="row">
      	<div class="contact-title"><?php the_title(); ?></div>
          <div class="col-md-12">
          	<div class="padding-wrapper">
          		<div class="details-row">
	              <ul>
	                <li class="location">
	                  <img src="<?php echo get_template_directory_uri() ?>/images/location-contact.png">  
	                  <span><?php the_field('address');?></span>
	                </li>
	                <li class="call">
	                  <img src="<?php echo get_template_directory_uri() ?>/images/call-contact.png">  
	                  <span><?php the_field('number');?></span>
	                </li>
	                <li class="mailicon">
	                  <img src="<?php echo get_template_directory_uri() ?>/images/mail-contact.png">  
	                  <a href="mailto:<?php the_field('email');?>"><?php the_field('email');?></a>
	                </li>
	              </ul>
	            </div> 
          	</di>
          </div>
          <div class="clearfix"></div>
          <div class="col-lg-12 col-centered">
          	<div class="row">
          		<div class="contact-title-form"><?php the_field('form_header');?></div>
          		<?php echo do_shortcode('[contact-form-7 id="148" title="contact form"]'); ?>
          	</div>
          </div>
    </div>
</section>


<?php endwhile; // end of the loop. ?>	
<?php
get_footer();
