<?php
/**
* Template Name: blog
*/
get_header(); ?>


<section class="s-featured">
  <div class="row">
    <div class="col-full">
      <div class="featured-slider featured aos-init aos-animate" data-aos="zoom-in" role="toolbar">
        
        
        
        <div aria-live="polite" class="slick-list draggable" style="padding: 0px 8%;">

            <div class="featured__slide " >
              <div class="entry">
                <div class="entry__background" style="background-image:url('<?php echo get_template_directory_uri() ?>/images/featured-watch.webp');"></div>
                <div class="entry__content">
                  <span class="entry__category"><a href="#0" tabindex="-1">Management</a></span>
                  <h1><a href="#0" title="" tabindex="-1">The Pomodoro Technique Really Works.</a></h1>
                  <div class="entry__info">
                    <a href="#0" class="entry__profile-pic" tabindex="-1">
                      
                    </a>
                    <ul class="entry__meta">
                      <li><a href="#0" tabindex="-1">John Doe</a></li>
                      <li>June 13, 2018</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div class="featured__slide "  aria-hidden="true" tabindex="-1">
            <div class="entry">
              <div class="entry__background" style="background-image:url('<?php echo get_template_directory_uri() ?>/images/featured-guitarman.webp');"></div>
              <div class="entry__content">
                <span class="entry__category"><a href="#0" tabindex="-1">LifeStyle</a></span>
                <h1><a href="#0" title="" tabindex="-1">The difference between Classics, Vintage &amp; Antique Cars.</a></h1>
                <div class="entry__info">
                  <a href="#0" class="entry__profile-pic" tabindex="-1">
                    
                  </a>
                  <ul class="entry__meta">
                    <li><a href="#0" tabindex="-1">John Doe</a></li>
                    <li>June 12, 2018</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

       </div>

     </div>
    </div>
  </div>
</section>

<script type="text/javascript">
jQuery('.featured-slider').slick({
            arrows: true,
            dots: true,
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            centerMode: true,
            centerPadding: '10%',
            pauseOnFocus: false,
            autoplaySpeed: 1500,
            responsive: [{
                breakpoint: 1400,
                settings: {
                    arrows: false,
                    centerPadding: '8%'
                }
            }, {
                breakpoint: 900,
                settings: {
                    arrows: false,
                    centerPadding: '5%'
                }
            }, {
                breakpoint: 400,
                settings: {
                    arrows: false,
                    centerMode: false
                }
            }]
        });
</script>

<?php
get_footer(); ?>
