<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WP_Bootstrap_Starter
 */

?>
			</div><!-- .row-->
		</div><!-- .container-fluid -->
	</div><!-- #content -->
		<footer id="site_footer" class="site_footer">
    	<div class="container">
        	<div class="row">
            	<div class="col-xs-12 footer_top">
                    <ul>
                        <li class="facabook"><a href="<?php echo get_theme_mod( 'facebook' ); ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li class="twitter"><a href="<?php echo get_theme_mod( 'twitter' ); ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li class="linkedin"><a href="<?php echo get_theme_mod( 'linkedin' ); ?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        <li class="instagram"><a href="<?php echo get_theme_mod( 'instagram' ); ?>" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
                <div class="col-xs-12 footer_bottom">
                    <ul>
                        <li class="copy"><?php echo get_theme_mod( 'copyright' ); ?></li>
                        <?php wp_nav_menu( array('menu' => 'footer') ); ?>
                    </ul>
                	
                    
                </div>
            </div>
        </div>
    </footer>


<?php wp_footer(); ?>
<script>
	new WOW().init();
</script>

<script type="text/javascript">
// header fixed
 //jQuery(window).scroll(function(){if(jQuery(window).scrollTop() >= 100) {jQuery('.navbar-static-top').addClass('fixed');} else {('.navbar-static-top').removeClass('fixed');}});

// skrllr
jQuery(function () {
    // Init function
    function skrollrInit() {skrollr.init({  smoothScrolling: false, mobileDeceleration: 0.004,forceHeight: false });}
    // If window width is large enough, initialize skrollr
    if (jQuery(window).width() > 1366) { skrollrInit();}
    jQuery(window).on('resize', function () {var _skrollr = skrollr.get(); var windowWidth = jQuery(window).width();if ( windowWidth <= 1200 && _skrollr !== undefined ) {  _skrollr.destroy(); } else if ( windowWidth > 1200 && _skrollr === undefined ) {skrollrInit(); }});
});
jQuery(document).ready(function(){jQuery(".name input,.city input").keypress(function(event){ var inputValue = event.charCode;if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)){event.preventDefault(); }});});
jQuery(".wpcf7-tel").keypress(function(event) {return /\d/.test(String.fromCharCode(event.keyCode));});
jQuery( document ).ready(function() {jQuery('.dropdown-toggle').attr('href' , '#');}); 
jQuery(window).scroll(function() {if (jQuery(this).scrollTop() >= 100) { jQuery('#return-to-top').fadeIn(200); } else { jQuery('#return-to-top').fadeOut(200); }});
jQuery('#return-to-top').click(function() { jQuery('body,html').animate({ scrollTop : 0 }, 500); });
jQuery("#scrolldown").click(function() {jQuery('html,body').animate({ scrollTop: jQuery(".about-section").offset().top},'slow');});
function openNav() {jQuery('#mySidenav').css('right', '0');}
function closeNav() {jQuery('#mySidenav').css('right', '-100%');}

</script>
<!-- Header Popup Menu -->
 <script type="text/javascript">
  jQuery('.close').click(function(){  
      jQuery('#myModal').removeClass('fademenuLeft');
      jQuery('body').removeClass('menulogo');
      
  })

// Product Menu   
jQuery( document ).ready(function() {
  jQuery('#menu-item-94').click(function(){
    var submenu = jQuery('#menu-item-94 ul').html();
    var menutitle = 'OUR SERVICES';       
    jQuery("#modalbody").html('<ul>'+submenu+'</ul>');
    jQuery(".menu-title h2").html(menutitle);
    jQuery('#myModal').modal('show');   
  })
})


 </script> 
 <!-- Header Popup Menu End-->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-148822302-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-148822302-1');
</script>

 
</body>
</html>
